
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <asm/siginfo.h>	
#include <linux/rcupdate.h>	
#include <linux/sched.h>	
#include <linux/debugfs.h>
#include <linux/uaccess.h>

MODULE_LICENSE("GPL");

#define SIG_TEST 44

struct denrty *file;

static ssize_t write_pid(struct file *file,const char __user *buf,size_t count,loff_t *ppos)
{
	char mybuf[10];
	int pid=0;
	int ret;
	struct siginfo info;
	struct task_struct *t;
	if(count>10)
	{
		return -EINVAL;
	}
	copy_from_user(mybuf,buf,count);
	sscanf(mybuf,"%d",&pid);
	printk("pid=%d\n",pid);
	memset(&info,0,sizeof(struct siginfo));
	info.si_signo=SIG_TEST;
	info.si_code=SI_QUEUE;
	info.si_int=1234;
	rcu_read_lock();
	t=find_task_by_pid_type(PIDTYPE_PID,pid);
	if(t==NULL)
	{
		printk("INVALID PID.\n");
	}
	rcu_read_unlock();
	ret=send_sig_info(SIG_TEST,&info,t);
	if(ret<0)
	{
		printk("error sending signal\n");
		return ret;
	}
	return count;
}
static const struct file_operations my_fops={
	.write=write_pid,
};
static int init(void)
{
	file=debugfs_create_file("signalconfpid",0200,NULL,NULL,&my_fops);
	return 0;
}
void exit_module(void)
{
	debugfs_remove(file);
	printk("THE SIGNAL SENDING MODULE HAS BEEN UNLOADED..");
}
module_init(init);
module_exit(exit_module);
