#include<linux/module.h>
#include<linux/interrupt.h>
static unsigned long volatile onesec;

void tasklet_action(unsigned long t)
{
	printk("tasklet action is being executed..\n");
}
void normal_action(unsigned long t)
{
	onesec = jiffies;
	printk("normal action is being executed..\n");
}
struct tasklet_struct my_tasklet={
	.next=NULL,
	.state=0,
	.count=ATOMIC_INIT(0),
	.func=tasklet_action,
	.data=0
};

void my_actions(void)
{
	printk("tasklet:do_work()\n");
	tasklet_schedule(&my_tasklet);
	normal_action(1);
}

int __init tasklet_module_init(void)
{
	onesec = jiffies;
	printk("tasklet:tasklet_module_init()\n");
	printk("module loaded %lu jiffies\n",jiffies);
	my_actions();
	return 0;
}
void __exit tasklet_module_exit(void)
{
	printk("tasklet:tasklet_module_exit");
}
module_init(tasklet_module_init);
module_exit(tasklet_module_exit);
