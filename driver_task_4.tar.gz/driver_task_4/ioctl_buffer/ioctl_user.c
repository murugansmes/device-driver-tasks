#include "ioctl_header.h"
#include<fcntl.h>
#include<unistd.h>
#include<sys/ioctl.h>
#include<stdio.h>
#include<stdlib.h>
ioctl_set_msg(int file_desc,char *message)
{
	int ret_val;
	ret_val=ioctl(file_desc,IOCTL_SET_MSG,message);
	if(ret_val<0)
	{
		printf("	ioctl_set_msg failed :%d\n",ret_val);
		exit(-1);
	}
}
ioctl_get_msg(int file_desc)
{
	int ret_val;
	char message[100];
	ret_val=ioctl(file_desc,IOCTL_GET_MSG,message);
	if(ret_val<0)
	{
		printf("	ioctl_get_msg failed:%d\n",ret_val);
		exit(-1);
	}
	printf("\n\n	MESSAGE READ FROM THE DEVICE FILE IS	    :%s\n\n",message);
}
void main()
{
	int file_desc,ret_val,i=0;
	char *msg;
	msg=malloc(10*sizeof(char));
	system("clear");
	printf("	ENTER THE MESSAGE TO BE SENT TO KERNEL SPACE:");
	while(1)
	{	
		scanf("%c",(msg+i));
		if(*(msg+i)=='\n')
		{
			*(msg+i)='\0';
			break;
		}
	i++;
	}
	file_desc=open(DEVICE_FILE_NAME,0);
	if(file_desc<0)
	{
		printf("	Cant open device file:%s\n",DEVICE_FILE_NAME);
		exit(-1);
	}
	ioctl_set_msg(file_desc,msg);
	ioctl_get_msg(file_desc);
	close(file_desc);
}
