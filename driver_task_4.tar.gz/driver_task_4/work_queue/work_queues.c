#include<linux/kernel.h>
#include<linux/module.h>
#include<linux/workqueue.h>

MODULE_LICENSE("GPL");
static struct workqueue_struct *queue;
static void work_func_1(struct work_struct *work1)
{
	printk(KERN_INFO "work 1\n");
}
static void work_func_2(struct work_struct *work2)
{
	printk(KERN_INFO "work 2\n");
}

DECLARE_WORK(work1,work_func_1);
DECLARE_WORK(work2,work_func_2);
int init_module(void)
{
	queue=create_singlethread_workqueue("myworkqueue");
	queue_work(queue,&work1);
	queue_work(queue,&work2);
	return 0;
}
void cleanup_module(void)
{
	cancel_work_sync(&work1);
	cancel_work_sync(&work2);
	destroy_workqueue(queue);
}
