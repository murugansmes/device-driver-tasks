#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/module.h>
#include<linux/syscalls.h>
#include<linux/fcntl.h>
#include<asm/uaccess.h>

static int read_file(char *filename)
{
	struct file *f;
	char buf[128];
	mm_segment_t fs;
	int i;
	for(i=0;i<128;i++)
	buf[i]=0;
	f=filp_open(filename,O_RDONLY,0);
	if(f==NULL)
	{
		printk(KERN_ALERT "filp_open error!!\n");
	}
	else
	{
		fs=get_fs();
		set_fs(get_ds());
		f->f_op->read(f,buf,128,&f->f_pos);
		set_fs(fs);
		printk(KERN_INFO "\n%s contains:\n\n%s\n",filename,buf);
	}
	filp_close(f,NULL);
	return 0;
}
int init(void)
{
	printk("\nFILE READING MODULE HAS BEEN LOADED..:\n");
	read_file("/proc/devices");
	return 0;
}
void exit_module(void)
{
	printk("\nFILE READING MODULE HAS BEEN REMOVED..\n");
}
module_init(init);
module_exit(exit_module);
